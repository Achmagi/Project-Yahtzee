﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace YahtzeeStap2
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        Random random = new Random();

        // Hier worden alle variabelen aangemaakt die worden gebruikt bij het spel om het spel goed te laten verlopen.
        public int dice1;
        public int dice2;
        public int dice3;
        public int dice4;
        public int dice5;


        public int OnesR1;
        public int TwosR1;
        public int ThreesR1;
        public int FoursR1;
        public int FivesR1;
        public int SixesR1;

        public int GroteStraatR1Number;
        public int GroteStraatR3Number;
        public int KleineStraatR1Number;
        public int KleineStraatR3Number;
        public int YahtzeeR1Number;
        public int YahtzeeR3Number;
        public int FullHouseR1Number;
        public int FullHouseR3Number;
        public int FourOfAKindR1Number;
        public int FourOfAKindR3Number;
        public int ThreeOfAKindR1Number;
        public int ThreeOfAKindR3Number;
        public int ChanceR1Number;
        public int ChanceR3Number;
        public int AantalPuntenR1Number;

        public bool diceThrow = false;
        public bool groteStraatBool = false;
        public bool kleineStraatBool = false;
        public bool yahtzeeBool = false;
        public bool fullHouseBool = false;
        public bool fourOfAKindBool = false;
        public bool threeOfAKindBool = false;
        public bool chanceBool = false;
        public bool winnaarBool = false;
        bool[] lockdice = new bool[5];


        


        // Dit zorgt ervoor dat je maar 1 keer de kies knop kan gebruiken totdat erweer opnieuw word gegooid
        //Gemaakt door Ahmed 
        private void RestFalse()
        {
            groteStraatBool = false;
            kleineStraatBool = false;
            yahtzeeBool = false;
            fullHouseBool = false;
            fourOfAKindBool = false;
            threeOfAKindBool = false;
            chanceBool = false;
        }

        //Dit zorgt ervoor dat alle locks los gaan als je op de gooi knop klikt
        //Gemaakt door Ahmed 
        private void LockLos()
        {
            lockdice[0] = false;
            lockdice[1] = false;
            lockdice[2] = false;
            lockdice[3] = false;
            lockdice[4] = false;
            
        }

        // Dit zorgt ervoor dat de text in een dice vernaderd dus dat er geen cijfers maar dice worden gebruikt
        //Gemaakt door Ahmed 
        public void NumberToDice()
        {
            if (dice1 == 1)
            {
                Dice1Text.Text = " ⚀";
            }

            if (dice1 == 2)
            {
                Dice1Text.Text = " ⚁";
            }

            if (dice1 == 3)
            {
                Dice1Text.Text = " ⚂";
            }

            if (dice1 == 4)
            {
                Dice1Text.Text = " ⚃";
            }

            if (dice1 == 5)
            {
                Dice1Text.Text = " ⚄";
            }

            if (dice1 == 6)
            {
                Dice1Text.Text = " ⚅";
            }

            if (dice2 == 1)
            {
                Dice2Text.Text = " ⚀";
            }

            if (dice2 == 2)
            {
                Dice2Text.Text = " ⚁";
            }

            if (dice2 == 3)
            {
                Dice2Text.Text = " ⚂";
            }

            if (dice2 == 4)
            {
                Dice2Text.Text = " ⚃";
            }

            if (dice2 == 5)
            {
                Dice2Text.Text = " ⚄";
            }

            if (dice2 == 6)
            {
                Dice2Text.Text = " ⚅";
            }

            if (dice3 == 1)
            {
                Dice3Text.Text = " ⚀";
            }

            if (dice3 == 2)
            {
                Dice3Text.Text = " ⚁";
            }

            if (dice3 == 3)
            {
                Dice3Text.Text = " ⚂";
            }

            if (dice3 == 4)
            {
                Dice3Text.Text = " ⚃";
            }

            if (dice3 == 5)
            {
                Dice3Text.Text = " ⚄";
            }

            if (dice3 == 6)
            {
                Dice3Text.Text = " ⚅";
            }

            if (dice4 == 1)
            {
                Dice4Text.Text = " ⚀";
            }

            if (dice4 == 2)
            {
                Dice4Text.Text = " ⚁";
            }

            if (dice4 == 3)
            {
                Dice4Text.Text = " ⚂";
            }

            if (dice4 == 4)
            {
                Dice4Text.Text = " ⚃";
            }

            if (dice4 == 5)
            {
                Dice4Text.Text = " ⚄";
            }

            if (dice4 == 6)
            {
                Dice4Text.Text = " ⚅";
            }

            if (dice5 == 1)
            {
                Dice5Text.Text = " ⚀";
            }

            if (dice5 == 2)
            {
                Dice5Text.Text = " ⚁";
            }

            if (dice5 == 3)
            {
                Dice5Text.Text = " ⚂";
            }

            if (dice5 == 4)
            {
                Dice5Text.Text = " ⚃";
            }

            if (dice5 == 5)
            {
                Dice5Text.Text = " ⚄";
            }

            if (dice5 == 6)
            {
                Dice5Text.Text = " ⚅";
            }






        }
        public MainPage()
        {
            this.InitializeComponent();
        }



        //Dit checkt of je Yahtzee of Fullhouse etc. hebt gegooid
        //Gemaakt door Ahmed 
        private void CheckFor()
        {
            // Dit maakt een array van alle dice
            //Gemaakt door Ahmed 
            int[] i = new int[5];

            i[0] = dice1;
            i[1] = dice2;
            i[2] = dice3;
            i[3] = dice4;
            i[4] = dice5;

            Array.Sort(i);

            //Three of a kind
            //Dit checkt of er three of a kind is gegooid, zo ja dan zet die de ThreeOfAKindBool op true
            //Gemaakt door Ahmed 

            if (((i[0] == 1) && (i[1] == 1) && (i[2] == 1)) ||
                ((i[0] == 2) && (i[1] == 2) && (i[2] == 2)) ||
                ((i[0] == 3) && (i[1] == 3) && (i[2] == 3)) ||
                ((i[0] == 4) && (i[1] == 4) && (i[2] == 4)) ||
                ((i[0] == 5) && (i[1] == 5) && (i[2] == 5)) ||
                ((i[0] == 6) && (i[1] == 6) && (i[2] == 6)) ||
                ((i[1] == 1) && (i[2] == 1) && (i[3] == 1)) ||
                ((i[1] == 2) && (i[2] == 2) && (i[3] == 2)) ||
                ((i[1] == 3) && (i[2] == 3) && (i[3] == 3)) ||
                ((i[1] == 4) && (i[2] == 4) && (i[3] == 4)) ||
                ((i[1] == 5) && (i[2] == 5) && (i[3] == 5)) ||
                ((i[1] == 6) && (i[2] == 6) && (i[3] == 6)) ||
                ((i[2] == 1) && (i[3] == 1) && (i[4] == 1)) ||
                ((i[2] == 2) && (i[3] == 2) && (i[4] == 2)) ||
                ((i[2] == 3) && (i[3] == 3) && (i[4] == 3)) ||
                ((i[2] == 4) && (i[3] == 4) && (i[4] == 4)) ||
                ((i[2] == 5) && (i[3] == 5) && (i[4] == 5)) ||
                ((i[2] == 6) && (i[3] == 6) && (i[4] == 6)))
            {
                threeOfAKindBool = true;
            }


            //Four of a kind
            //Dit checkt of er four of a kind is gegooid, zo ja dan zet die de FourOfAKindBool op true
            //Gemaakt door Ahmed 

            if (((i[0] == 1) && (i[1] == 1) && (i[2] == 1) && (i[3] == 1)) ||
                ((i[0] == 2) && (i[1] == 2) && (i[2] == 2) && (i[3] == 2)) ||
                ((i[0] == 3) && (i[1] == 3) && (i[2] == 3) && (i[3] == 3)) ||
                ((i[0] == 4) && (i[1] == 4) && (i[2] == 4) && (i[3] == 4)) ||
                ((i[0] == 5) && (i[1] == 5) && (i[2] == 5) && (i[3] == 5)) ||
                ((i[0] == 6) && (i[1] == 6) && (i[2] == 6) && (i[3] == 6)) ||
                ((i[1] == 1) && (i[2] == 1) && (i[3] == 1) && (i[4] == 1)) ||
                ((i[1] == 2) && (i[2] == 2) && (i[3] == 2) && (i[4] == 2)) ||
                ((i[1] == 3) && (i[2] == 3) && (i[3] == 3) && (i[4] == 3)) ||
                ((i[1] == 4) && (i[2] == 4) && (i[3] == 4) && (i[4] == 4)) ||
                ((i[1] == 5) && (i[2] == 5) && (i[3] == 5) && (i[4] == 5)) ||
                ((i[1] == 6) && (i[2] == 6) && (i[3] == 6) && (i[4] == 6)))

            {
                fourOfAKindBool = true;
            }



            //Kleine Straat
            //Dit checkt of er kleine straat is gegooid, zo ja dan zet die de KleineStraatBool op true
            //Gemaakt door Ahmed 

            //Er komen problemen als er dezelfde nummers in voorkomen dus dit zorgt ervoor dat alle dubbele getallen naar links gaan
            //(source: https://www.codeproject.com/Articles/8657/A-Simple-Yahtzee-Game)
            for (int j = 0; j < 4; j++)
            {
                int temp = 0;
                if (i[j] == i[j + 1])
                {
                    temp = i[j];

                    for (int k = j; k < 4; k++)
                    {
                        i[k] = i[k + 1];
                    }

                    i[4] = temp;
                }
            }

            if (((i[0] == 1) && (i[1] == 2) && (i[2] == 3) && (i[3] == 4)) ||
                ((i[0] == 2) && (i[1] == 3) && (i[2] == 4) && (i[3] == 5)) ||
                ((i[0] == 3) && (i[1] == 4) && (i[2] == 5) && (i[3] == 6)) ||
                ((i[1] == 1) && (i[2] == 2) && (i[3] == 3) && (i[4] == 4)) ||
                ((i[1] == 2) && (i[2] == 3) && (i[3] == 4) && (i[4] == 5)) ||
                ((i[1] == 3) && (i[2] == 4) && (i[3] == 5) && (i[4] == 6)))
            {
                kleineStraatBool = true;
            }


            //Grote Straat
            //Dit checkt of er grote straat is gegooid, zo ja dan zet die de GroteStraatBool op true
            //Gemaakt door Ahmed 

            if (((i[0] == 1) && (i[1] == 2) && (i[2] == 3) && (i[3] == 4) && (i[4] == 5)) ||
                ((i[0] == 2) && (i[1] == 3) && (i[2] == 4) && (i[3] == 5) && (i[4] == 6)))
            {
                groteStraatBool = true;
            }

            //Yahtzee
            //Dit checkt of er Yahtzee is gegooid, zo ja dan zet die de YahtzeeBool op true
            //Gemaakt door Ahmed 

            if (((i[0] == 1) && (i[1] == 1) && (i[2] == 1) && (i[3] == 1) && (i[4] == 1)) ||
                ((i[0] == 2) && (i[1] == 2) && (i[2] == 2) && (i[3] == 2) && (i[4] == 2)) ||
                ((i[0] == 3) && (i[1] == 3) && (i[2] == 3) && (i[3] == 3) && (i[4] == 3)) ||
                ((i[0] == 4) && (i[1] == 4) && (i[2] == 4) && (i[3] == 4) && (i[4] == 4)) ||
                ((i[0] == 5) && (i[1] == 5) && (i[2] == 5) && (i[3] == 5) && (i[4] == 5)) ||
                ((i[0] == 6) && (i[1] == 6) && (i[2] == 6) && (i[3] == 6) && (i[4] == 6)))

            {
                yahtzeeBool = true;
            }

            //FullHouse
            //Dit checkt of er FullHouse is gegooid, zo ja dan zet die de FullHouseBool op true
            //Gemaakt door Thijs & Chris
            
            int[] fullHouseArr = new int[] { dice1, dice2, dice3, dice4, dice5 };
            Array.Sort(fullHouseArr);
            if ((((dice1 == dice2) && (dice2 == dice3)) &&
                     (dice4 == dice5) &&
                     (dice3 != dice4)) ||
                    ((dice1 == dice2) &&
                     ((dice3 == dice4) && (dice4 == dice5)) &&
                     (dice2 != dice3)))
            {
                fullHouseBool = true;
            }



        }


        //Dit zorgt ervoor dat je de dobbelstenen kan gooien
        //Gemaakt door Ahmed 
        private void ThrowButton_Click_1(object sender, RoutedEventArgs e)
        {
            //Dit checkt of je gewonnen hebt, zo ja dan kan je niet meer gooien
            if (winnaarBool == false)
            {
                //Dit kijkt of de dice gelocked is ofniet, zo ja dan word die dobbelsteen niet meer gegooid
                if (lockdice[0] == false)
                {
                   dice1 = random.Next(1, 7);
                }

                if (lockdice[1] == false)
                {
                    dice2 = random.Next(1, 7);
                }
                
                if (lockdice[2] == false)
                {
                    dice3 = random.Next(1, 7);
                }
                
                if (lockdice[3] == false)
                {
                    dice4 = random.Next(1, 7);
                }
                
                if (lockdice[4] == false)
                {
                    dice5 = random.Next(1, 7);
                }

                diceThrow = true;
                chanceBool = true;


                //Dit called alle belangrijke methods
                NumberToDice();
                CheckFor();

                //Dit zorgt voor de aantal punten
                AantalPuntenR1Text.Text = AantalPuntenR1Number.ToString();

            }
            else
            {
                ThrowButton.Content = "Klaar";
            }



        }


        //Dit zorgt ervoor dat je naar de uitleg pagina gaat
        //Gemaakt door Dylan 
        private void UitlegPageButton_Click(object sender, RoutedEventArgs e)
        {
            UitlegPage uitlegPage = new UitlegPage();
            this.Content = uitlegPage;

        }
        //Met dit kun je kiezen voor ThreeOfAKind
        //Gemaakt door Ahmed & Wouter
        private void KiesThreeOfAKindButton_Click(object sender, RoutedEventArgs e)
        {
            if (threeOfAKindBool == true)
            {
                ThreeOfAKindR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                AantalPuntenR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                ThreeOfAKindR1Text.Text = ThreeOfAKindR1Number.ToString();
                ThreeOfAKindR3Number += 1;
                ThreeOfAKindR3Text.Text = ThreeOfAKindR3Number.ToString();
                RestFalse();
                LockLos();
            }


        }

        //Met dit kun je kiezen voor Four Of A Kind
        //Gemaakt door Ahmed & Wouter
        private void KiesFourOfAKindButton_Click(object sender, RoutedEventArgs e)
        {
            if (fourOfAKindBool == true)
            {
                FourOfAKindR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                AantalPuntenR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                FourOfAKindR1Text.Text = FourOfAKindR1Number.ToString();
                FourOfAKindR3Number += 1;
                fourOfAKindR3Text.Text = FourOfAKindR3Number.ToString();
                RestFalse();
                LockLos();
            }
        }

        //Met dit kun je kiezen voor Kleine Straat
        //Gemaakt door Ahmed & Wouter
        private void KiesKleineStraatButton_Click(object sender, RoutedEventArgs e)
        {
            if (kleineStraatBool == true)
            {
                KleineStraatR1Number += 30;
                AantalPuntenR1Number += 30;
                KleineStraatR1Text.Text = KleineStraatR1Number.ToString();
                KleineStraatR3Number += 1;
                KleineStraatR3Text.Text = KleineStraatR3Number.ToString();
                RestFalse();
                LockLos();
            }


        }

        //Met dit kun je kiezen voor FullHouse
        //Gemaakt door Ahmed & Wouter
        private void KiesFullHouseButton_Click(object sender, RoutedEventArgs e)
        {
            if (fullHouseBool == true)
            {
                FullHouseR1Number += 25;
                AantalPuntenR1Number += 25;
                FullHouseR1Text.Text = FullHouseR1Number.ToString();
                FullHouseR3Number += 1;
                FullHouseR3Text.Text = FullHouseR3Number.ToString();
                RestFalse();
                LockLos();
            }


        }

        //Met dit kun je kiezen voor GroteStraat
        //Gemaakt door Ahmed & Wouter
        private void KiesGroteStraatButton_Click(object sender, RoutedEventArgs e)
        {
            if (groteStraatBool == true)
            {
                GroteStraatR1Number += 40;
                AantalPuntenR1Number += 40;
                GroteStraatR1Text.Text = GroteStraatR1Number.ToString();
                GroteStraatR3Number += 1;
                GroteStraatR3Text.Text = GroteStraatR3Number.ToString();
                RestFalse();
                LockLos();
            }


        }

        //Met dit kun je kiezen voor Chance
        //Gemaakt door Ahmed & Wouter
        private void KiesChanceButton_Click(object sender, RoutedEventArgs e)
        {
            if (chanceBool == true && ChanceR3Number == 0)
            {
                ChanceR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                AantalPuntenR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                ChanceR1Text.Text = ChanceR1Number.ToString();
                ChanceR3Number += 1;
                ChanceR3Text.Text = ChanceR3Number.ToString();
                RestFalse();
                LockLos();
            }


        }

        //Met dit kun je kiezen voor Yahtzee
        //Gemaakt door Ahmed & Wouter
        private void KiesYahtzeeButton_Click(object sender, RoutedEventArgs e)
        {
            if (yahtzeeBool)
            {
                YahtzeeR1Number += 50;
                AantalPuntenR1Number += 50;
                winnaarBool = true;
                YahtzeeR1Text.Text = YahtzeeR1Number.ToString();
                YahtzeeR3Number += 1;
                YahtzeeR3Text.Text = YahtzeeR3Number.ToString();
                RestFalse();
                LockLos();

            }



        }

        //Dit zorgt ervoor dat lock button 1 werkt
        //Gemaakt door Ahmed
        private void LockDice1Button_Click(object sender, RoutedEventArgs e)
        {
            lockdice[0] = !lockdice[0];
        }

        //Dit zorgt ervoor dat lock button 2 werkt
        //Gemaakt door Ahmed
        private void LockDice2Button_Click(object sender, RoutedEventArgs e)
        {
            lockdice[1] = !lockdice[1];
        }

        //Dit zorgt ervoor dat lock button 3 werkt
        //Gemaakt door Ahmed
        private void LockDice3Button_Click(object sender, RoutedEventArgs e)
        {
            lockdice[2] = !lockdice[2];
        }

        //Dit zorgt ervoor dat lock button 4 werkt
        //Gemaakt door Ahmed
        private void LockDice4Button_Click(object sender, RoutedEventArgs e)
        {
            lockdice[3] = !lockdice[3];
        }

        //Dit zorgt ervoor dat lock button 5 werkt
        //Gemaakt door Ahmed
        private void LockDice5Button_Click(object sender, RoutedEventArgs e)
        {
            lockdice[4] = !lockdice[4];
        }

        //Ones tot en met sixes
        //Gemaakt door Wouter
        private void KiesOnesButton_Click(object sender, RoutedEventArgs e)
        {
            if (dice1 == 1)
            {
                OnesR1 += 1;
            }
            if (dice2 == 1)
            {
                OnesR1 += 1;
            }
            if (dice3 == 1)
            {
                OnesR1 += 1;
            }
            if (dice4 == 1)
            {
                OnesR1 += 1;
            }
            if (dice5 == 1)
            {
                OnesR1 += 1;
            }
            OnesR1Text.Text = OnesR1.ToString();
        }

        private void KiesTwosButton_Click(object sender, RoutedEventArgs e)
        {
            if (dice1 == 2)
            {
                TwosR1 += 2;
            }
            if (dice2 == 2)
            {
                TwosR1 += 2;
            }
            if (dice3 == 2)
            {
                TwosR1 += 2;
            }
            if (dice4 == 2)
            {
                TwosR1 += 2;
            }
            if (dice5 == 2)
            {
                TwosR1 += 2;
            }
            TwosR1Text.Text = TwosR1.ToString();
        }

        private void KiesThreesButton_Click(object sender, RoutedEventArgs e)
        {
            if (dice1 == 3)
            {
                ThreesR1 += 3;
            }
            if (dice2 == 3)
            {
                ThreesR1 += 3;
            }
            if (dice3 == 3)
            {
                ThreesR1 += 3;
            }
            if (dice4 == 3)
            {
                ThreesR1 += 3;
            }
            if (dice5 == 3)
            {
                ThreesR1 += 3;
            }
            ThreesR1Text.Text = ThreesR1.ToString();
        }

        private void KiesFoursButton_Click(object sender, RoutedEventArgs e)
        {
            if (dice1 == 4)
            {
                FoursR1 += 4;
            }
            if (dice2 == 4)
            {
                FoursR1 += 4;
            }
            if (dice3 == 4)
            {
                FoursR1 += 4;
            }
            if (dice4 == 4)
            {
                FoursR1 += 4;
            }
            if (dice5 == 4)
            {
                FoursR1 += 4;
            }
            FoursR1Text.Text = FoursR1.ToString();
        }

        private void KiesFivesButton_Click(object sender, RoutedEventArgs e)
        {
            if (dice1 == 5)
            {
                FivesR1 += 5;
            }
            if (dice2 == 5)
            {
                FivesR1 += 5;
            }
            if (dice3 == 5)
            {
                FivesR1 += 5;
            }
            if (dice4 == 5)
            {
                FivesR1 += 5;
            }
            if (dice5 == 5)
            {
                FivesR1 += 5;
            }
            FivesR1Text.Text = FivesR1.ToString();
        }

        private void KiesSixesButton_Click(object sender, RoutedEventArgs e)
        {
            if (dice1 == 6)
            {
                SixesR1 += 6;
            }
            if (dice2 == 6)
            {
                SixesR1 += 6;
            }
            if (dice3 == 6)
            {
                SixesR1 += 6;
            }
            if (dice4 == 6)
            {
                SixesR1 += 6;
            }
            if (dice5 == 6)
            {
                SixesR1 += 6;
            }
            SixesR1Text.Text = SixesR1.ToString();
        }

    }
}
