﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace ProjectYahtzeeStap1
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        Random random = new Random();

        public int dice1;
        public int dice2;
        public int dice3;
        public int dice4;
        public int dice5;

        public int GroteStraatR1Number;
        public int KleineStraatR1Number;
        public int YahtzeeR1Number;
        public int FullHouseR1Number;
        public int FourOfAKindR1Number;
        public int ThreeOfAKindR1Number;
        public int ChanceR1Number;
        public int AantalPuntenR1Number;

        public bool diceThrow = false;
        public bool GroteStraatBool = false;
        public bool KleineStraatBool = false;
        public bool YahtzeeBool = false;
        public bool FullHouseBool = false;
        public bool FourOfAKindBool = false;
        public bool ThreeOfAKindBool = false;
        public bool ChanceBool = false;

        public void NumberToDice()
        {
            if (dice1 == 1)
            {
                Dice1Text.Text = " ⚀";
            }

            if (dice1 == 2)
            {
                Dice1Text.Text = " ⚁";
            }

            if (dice1 == 3)
            {
                Dice1Text.Text = " ⚂";
            }

            if (dice1 == 4)
            {
                Dice1Text.Text = " ⚃";
            }

            if (dice1 == 5)
            {
                Dice1Text.Text = " ⚄";
            }

            if (dice1 == 6)
            {
                Dice1Text.Text = " ⚅";
            }

            if (dice2 == 1)
            {
                Dice2Text.Text = " ⚀";
            }

            if (dice2 == 2)
            {
                Dice2Text.Text = " ⚁";
            }

            if (dice2 == 3)
            {
                Dice2Text.Text = " ⚂";
            }

            if (dice2 == 4)
            {
                Dice2Text.Text = " ⚃";
            }

            if (dice2 == 5)
            {
                Dice2Text.Text = " ⚄";
            }

            if (dice2 == 6)
            {
                Dice2Text.Text = " ⚅";
            }

            if (dice3 == 1)
            {
                Dice3Text.Text = " ⚀";
            }

            if (dice3 == 2)
            {
                Dice3Text.Text = " ⚁";
            }

            if (dice3 == 3)
            {
                Dice3Text.Text = " ⚂";
            }

            if (dice3 == 4)
            {
                Dice3Text.Text = " ⚃";
            }

            if (dice3 == 5)
            {
                Dice3Text.Text = " ⚄";
            }

            if (dice3 == 6)
            {
                Dice3Text.Text = " ⚅";
            }

            if (dice4 == 1)
            {
                Dice4Text.Text = " ⚀";
            }

            if (dice4 == 2)
            {
                Dice4Text.Text = " ⚁";
            }

            if (dice4 == 3)
            {
                Dice4Text.Text = " ⚂";
            }

            if (dice4 == 4)
            {
                Dice4Text.Text = " ⚃";
            }

            if (dice4 == 5)
            {
                Dice4Text.Text = " ⚄";
            }

            if (dice4 == 6)
            {
                Dice4Text.Text = " ⚅";
            }

            if (dice5 == 1)
            {
                Dice5Text.Text = " ⚀";
            }

            if (dice5 == 2)
            {
                Dice5Text.Text = " ⚁";
            }

            if (dice5 == 3)
            {
                Dice5Text.Text = " ⚂";
            }

            if (dice5 == 4)
            {
                Dice5Text.Text = " ⚃";
            }

            if (dice5 == 5)
            {
                Dice5Text.Text = " ⚄";
            }

            if (dice5 == 6)
            {
                Dice5Text.Text = " ⚅";
            }






        }
        public MainPage()
        {
            this.InitializeComponent();
        }

        private void CheckFor()
        {






            //Three of a kind

            if (dice1 == 1 && dice2 == 1 && dice3 == 1 && dice4 != 1 && dice5 != 1 ||
               dice1 == 2 && dice2 == 2 && dice3 == 2 && dice4 != 2 && dice5 != 2 ||
               dice1 == 3 && dice2 == 3 && dice3 == 3 && dice4 != 3 && dice5 != 3 ||
               dice1 == 4 && dice2 == 4 && dice3 == 4 && dice4 != 4 && dice5 != 4 ||
               dice1 == 5 && dice2 == 5 && dice3 == 5 && dice4 != 5 && dice5 != 5 ||
               dice1 != 1 && dice2 != 1 && dice3 == 1 && dice4 == 1 && dice5 == 1 ||
               dice1 != 2 && dice2 != 2 && dice3 == 2 && dice4 == 2 && dice5 == 2 ||
               dice1 != 3 && dice2 != 3 && dice3 == 3 && dice4 == 3 && dice5 == 3 ||
               dice1 != 4 && dice2 != 4 && dice3 == 4 && dice4 == 4 && dice5 == 4 ||
               dice1 != 5 && dice2 != 5 && dice3 == 5 && dice4 == 5 && dice5 == 5 ||
               dice1 != 1 && dice2 == 1 && dice3 == 1 && dice4 == 1 && dice5 != 1 ||
               dice1 != 2 && dice2 == 2 && dice3 == 2 && dice4 == 2 && dice5 != 2 ||
               dice1 != 3 && dice2 == 3 && dice3 == 3 && dice4 == 3 && dice5 != 3 ||
               dice1 != 4 && dice2 == 4 && dice3 == 4 && dice4 == 4 && dice5 != 4 ||
               dice1 != 5 && dice2 == 5 && dice3 == 5 && dice4 == 5 && dice5 != 5 ||
               dice1 == 1 && dice2 == 1 && dice3 != 1 && dice4 != 1 && dice5 == 1 ||
               dice1 == 2 && dice2 == 2 && dice3 != 2 && dice4 != 2 && dice5 == 2 ||
               dice1 == 3 && dice2 == 3 && dice3 != 3 && dice4 != 3 && dice5 == 3 ||
               dice1 == 4 && dice2 == 4 && dice3 != 4 && dice4 != 4 && dice5 == 4 ||
               dice1 == 5 && dice2 == 5 && dice3 != 5 && dice4 != 5 && dice5 == 5 ||
               dice1 != 1 && dice2 == 1 && dice3 != 1 && dice4 == 1 && dice5 == 1 ||
               dice1 != 2 && dice2 == 2 && dice3 != 2 && dice4 == 2 && dice5 == 2 ||
               dice1 != 3 && dice2 == 3 && dice3 != 3 && dice4 == 3 && dice5 == 3 ||
               dice1 != 4 && dice2 == 4 && dice3 != 4 && dice4 == 4 && dice5 == 4 ||
               dice1 != 5 && dice2 == 5 && dice3 != 5 && dice4 == 5 && dice5 == 5 ||
               dice1 == 1 && dice2 != 1 && dice3 == 1 && dice4 != 1 && dice5 == 1 ||
               dice1 == 2 && dice2 != 2 && dice3 == 2 && dice4 != 2 && dice5 == 2 ||
               dice1 == 3 && dice2 != 3 && dice3 == 3 && dice4 != 3 && dice5 == 3 ||
               dice1 == 4 && dice2 != 4 && dice3 == 4 && dice4 != 4 && dice5 == 4 ||
               dice1 == 5 && dice2 != 5 && dice3 == 5 && dice4 != 5 && dice5 == 5 ||
               dice1 == 1 && dice2 == 1 && dice3 != 1 && dice4 == 1 && dice5 != 1 ||
               dice1 == 2 && dice2 == 2 && dice3 != 2 && dice4 == 2 && dice5 != 2 ||
               dice1 == 3 && dice2 == 3 && dice3 != 3 && dice4 == 3 && dice5 != 3 ||
               dice1 == 4 && dice2 == 4 && dice3 != 4 && dice4 == 4 && dice5 != 4 ||
               dice1 == 5 && dice2 == 5 && dice3 != 5 && dice4 == 5 && dice5 != 5)
            {
                ThreeOfAKindBool = true;
                //ThreeOfAKindR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                //ThreeOfAKindR1Text.Text = ThreeOfAKindR1Number.ToString();

            }


            //Four of a kind
            if ((dice1 == 1 && dice2 == 1 && dice3 == 1 && dice4 == 1) || (dice1 == 2 && dice2 == 2 && dice3 == 2 && dice4 == 2) || (dice1 == 3 && dice2 == 3 && dice3 == 3 && dice4 == 3) || (dice1 == 4 && dice2 == 4 && dice3 == 4 && dice4 == 4) || (dice1 == 5 && dice2 == 5 && dice3 == 5 && dice4 == 5) || (dice1 == 6 && dice2 == 6 && dice3 == 6 && dice4 == 6) || (dice2 == 1 && dice3 == 1 && dice4 == 1 && dice5 == 1) || (dice2 == 2 && dice3 == 2 && dice4 == 2 && dice5 == 2) || (dice2 == 3 && dice3 == 3 && dice4 == 3 && dice5 == 3) || (dice2 == 4 && dice3 == 4 && dice4 == 4 && dice5 == 4) || (dice2 == 5 && dice3 == 5 && dice4 == 5 && dice5 == 5) || (dice2 == 6 && dice3 == 6 && dice4 == 6 && dice5 == 6))
            {
                FourOfAKindBool = true;
                //FourOfAKindR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                //FourOfAKindR1Text.Text = FourOfAKindR1Number.ToString();
            }



            //Kleine Straat
            if (((dice1 == 1 || dice2 == 1 || dice3 == 1 || dice4 == 1 || dice5 == 1) && (dice1 == 2 || dice2 == 2 || dice3 == 2 || dice4 == 2 || dice5 == 2) && (dice1 == 3 || dice2 == 3 || dice3 == 3 || dice4 == 3 || dice5 == 3) && (dice1 == 4 || dice2 == 4 || dice3 == 4 || dice4 == 4 || dice5 == 4)) || ((dice1 == 2 || dice2 == 2 || dice3 == 2 || dice4 == 2 || dice5 == 2) && (dice1 == 3 || dice2 == 3 || dice3 == 3 || dice4 == 3 || dice5 == 3) && (dice1 == 4 || dice2 == 4 || dice3 == 4 || dice4 == 4 || dice5 == 4) && (dice1 == 5 || dice2 == 5 || dice3 == 5 || dice4 == 5 || dice5 == 5)) || ((dice1 == 3 || dice2 == 3 || dice3 == 3 || dice4 == 3 || dice5 == 3) && (dice1 == 4 || dice2 == 4 || dice3 == 4 || dice4 == 4 || dice5 == 4) && (dice1 == 5 || dice2 == 5 || dice3 == 5 || dice4 == 5 || dice5 == 5) && (dice1 == 6 || dice2 == 6 || dice3 == 6 || dice4 == 6 || dice5 == 6)))
            {
                KleineStraatBool = true;
                //KleineStraatR1Number += 30;
                //KleineStraatR1Text.Text = KleineStraatR1Number.ToString();
            }


            //Grote Straat
            if ((dice1 == 1 || dice2 == 1 || dice3 == 1 || dice4 == 1 || dice5 == 1) && (dice1 == 2 || dice2 == 2 || dice3 == 2 || dice4 == 2 || dice5 == 2) && (dice1 == 3 || dice2 == 3 || dice3 == 3 || dice4 == 3 || dice5 == 3) && (dice1 == 4 || dice2 == 4 || dice3 == 4 || dice4 == 4 || dice5 == 4) && (dice1 == 5 || dice2 == 5 || dice3 == 5 || dice4 == 5 || dice5 == 5) || (dice1 == 2 || dice2 == 2 || dice3 == 2 || dice4 == 2 || dice5 == 2) && (dice1 == 3 || dice2 == 3 || dice3 == 3 || dice4 == 3 || dice5 == 3) && (dice1 == 4 || dice2 == 4 || dice3 == 4 || dice4 == 4 || dice5 == 4) && (dice1 == 5 || dice2 == 5 || dice3 == 5 || dice4 == 5 || dice5 == 5) && (dice1 == 6 || dice2 == 6 || dice3 == 6 || dice4 == 6 || dice5 == 6))
            {
                GroteStraatBool = true;
                //GroteStraatR1Number += 40;
                //GroteStraatR1Text.Text = GroteStraatR1Number.ToString();
            }

            //Yahtzee
            if ((dice1 == 1 && dice2 == 1 && dice3 == 1 && dice4 == 1 && dice4 == 1 && dice5 == 1) || (dice1 == 2 && dice2 == 2 && dice3 == 2 && dice4 == 2 && dice4 == 2 && dice5 == 2) || (dice1 == 3 && dice2 == 3 && dice3 == 3 && dice4 == 3 && dice4 == 3 && dice5 == 3) || (dice1 == 4 && dice2 == 4 && dice3 == 4 && dice4 == 4 && dice4 == 4 && dice5 == 4) || (dice1 == 5 && dice2 == 5 && dice3 == 5 && dice4 == 5 && dice4 == 5 && dice5 == 5) || (dice1 == 6 && dice2 == 6 && dice3 == 6 && dice4 == 6 && dice4 == 6 && dice5 == 6))
            {
                YahtzeeBool = true;
                //YahtzeeR1Number += 50;
                //YahtzeeR1Text.Text = YahtzeeR1Number.ToString();
            }

            //FullHouse
            int[] arr = new int[] { dice1, dice2, dice3, dice4, dice5 };
            Array.Sort(arr);
            if ((((dice1 == dice2) && (dice2 == dice3)) &&
                     (dice4 == dice5) &&
                     (dice3 != dice4)) ||
                    ((dice1 == dice2) &&
                     ((dice3 == dice4) && (dice4 == dice5)) &&
                     (dice2 != dice3)))
            {
                FullHouseBool = true;
                //FullHouseR1Number += 25;
                //FullHouseR1Text.Text = FullHouseR1Number.ToString();
            }



        }



        //private void ThrowButton_Click(object sender, RoutedEventArgs e)
        //{
        //    dice1 = random.Next(1, 7);
        //    dice2 = random.Next(1, 7);
        //    dice3 = random.Next(1, 7);
        //    dice4 = random.Next(1, 7); 
        //    dice5 = random.Next(1, 7);

        //    NumberToDice();
        //    CheckFor();
        //}

        private void ThrowButton_Click_1(object sender, RoutedEventArgs e)
        {
            dice1 = random.Next(1, 7);
            dice2 = random.Next(1, 7);
            dice3 = random.Next(1, 7);
            dice4 = random.Next(1, 7);
            dice5 = random.Next(1, 7);

            diceThrow = true;
            ChanceBool = true;


            NumberToDice();
            CheckFor();

            AantalPuntenR1Text.Text = AantalPuntenR1Number.ToString();



        }



        private void UitlegPageButton_Click(object sender, RoutedEventArgs e)
        {
            UitlegPage uitlegPage = new UitlegPage();
            this.Content = uitlegPage;
        }

        private void KiesThreeOfAKindButton_Click(object sender, RoutedEventArgs e)
        {
            if (ThreeOfAKindBool == true)
            {
                ThreeOfAKindR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                AantalPuntenR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                ThreeOfAKindR1Text.Text = ThreeOfAKindR1Number.ToString();
                ThreeOfAKindBool = false;
            }


        }

        private void KiesFourOfAKindButton_Click(object sender, RoutedEventArgs e)
        {
            if (FourOfAKindBool == true)
            {
                FourOfAKindR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                AantalPuntenR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                FourOfAKindR1Text.Text = FourOfAKindR1Number.ToString();
                FourOfAKindBool = false;
            }
        }

        private void KiesKleineStraatButton_Click(object sender, RoutedEventArgs e)
        {
            if (KleineStraatBool == true)
            {
                KleineStraatR1Number += 30;
                AantalPuntenR1Number += 30;
                KleineStraatR1Text.Text = KleineStraatR1Number.ToString();
                KleineStraatBool = false;
            }


        }

        private void KiesFullHouseButton_Click(object sender, RoutedEventArgs e)
        {
            if (FullHouseBool == true)
            {
                FullHouseR1Number += 25;
                AantalPuntenR1Number += 25;
                FullHouseR1Text.Text = FullHouseR1Number.ToString();
                FullHouseBool = false;
            }


        }

        private void KiesGroteStraatButton_Click(object sender, RoutedEventArgs e)
        {
            if (GroteStraatBool == true)
            {
                GroteStraatBool = true;
                GroteStraatR1Number += 40;
                AantalPuntenR1Number += 40;
                GroteStraatR1Text.Text = GroteStraatR1Number.ToString();
            }


        }

        private void KiesChanceButton_Click(object sender, RoutedEventArgs e)
        {
            if (ChanceBool == true)
            {
                ChanceR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                AantalPuntenR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                ChanceR1Text.Text = ChanceR1Number.ToString();
                ChanceBool = false;
            }


        }

        private void KiesYahtzeeButton_Click(object sender, RoutedEventArgs e)
        {
            if (YahtzeeBool == true)
            {
                YahtzeeR1Number += 50;
                AantalPuntenR1Number += 50;

                YahtzeeR1Text.Text = YahtzeeR1Number.ToString();
                YahtzeeBool = false;
            }


        }

    }
}
