﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace YahtzeeStap2
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        Random random = new Random();

        public int dice1;
        public int dice2;
        public int dice3;
        public int dice4;
        public int dice5;

        public int GroteStraatR1Number;
        public int GroteStraatR3Number;
        public int KleineStraatR1Number;
        public int KleineStraatR3Number;
        public int YahtzeeR1Number;
        public int YahtzeeR3Number;
        public int FullHouseR1Number;
        public int FullHouseR3Number;
        public int FourOfAKindR1Number;
        public int FourOfAKindR3Number;
        public int ThreeOfAKindR1Number;
        public int ThreeOfAKindR3Number;
        public int ChanceR1Number;
        public int ChanceR3Number;
        public int AantalPuntenR1Number;

        public bool diceThrow = false;
        public bool GroteStraatBool = false;
        public bool KleineStraatBool = false;
        public bool YahtzeeBool = false;
        public bool FullHouseBool = false;
        public bool FourOfAKindBool = false;
        public bool ThreeOfAKindBool = false;
        public bool ChanceBool = false;
        public bool WinnaarBool = false;
        public bool LockBoolDice1;
        public bool LockBoolDice2;
        public bool LockBoolDice3;
        public bool LockBoolDice4;
        public bool LockBoolDice5;


        private void RestFalse()
        {
            GroteStraatBool = false;
            KleineStraatBool = false;
            YahtzeeBool = false;
            FullHouseBool = false;
            FourOfAKindBool = false;
            ThreeOfAKindBool = false;
            ChanceBool = false;
        }

        private void LockLos()
        {
            LockBoolDice1 = false;
            LockBoolDice2 = false;
            LockBoolDice3 = false;
            LockBoolDice4 = false;
            LockBoolDice5 = false;
        }

        public void NumberToDice()
        {
            if (dice1 == 1)
            {
                Dice1Text.Text = " ⚀";
            }

            if (dice1 == 2)
            {
                Dice1Text.Text = " ⚁";
            }

            if (dice1 == 3)
            {
                Dice1Text.Text = " ⚂";
            }

            if (dice1 == 4)
            {
                Dice1Text.Text = " ⚃";
            }

            if (dice1 == 5)
            {
                Dice1Text.Text = " ⚄";
            }

            if (dice1 == 6)
            {
                Dice1Text.Text = " ⚅";
            }

            if (dice2 == 1)
            {
                Dice2Text.Text = " ⚀";
            }

            if (dice2 == 2)
            {
                Dice2Text.Text = " ⚁";
            }

            if (dice2 == 3)
            {
                Dice2Text.Text = " ⚂";
            }

            if (dice2 == 4)
            {
                Dice2Text.Text = " ⚃";
            }

            if (dice2 == 5)
            {
                Dice2Text.Text = " ⚄";
            }

            if (dice2 == 6)
            {
                Dice2Text.Text = " ⚅";
            }

            if (dice3 == 1)
            {
                Dice3Text.Text = " ⚀";
            }

            if (dice3 == 2)
            {
                Dice3Text.Text = " ⚁";
            }

            if (dice3 == 3)
            {
                Dice3Text.Text = " ⚂";
            }

            if (dice3 == 4)
            {
                Dice3Text.Text = " ⚃";
            }

            if (dice3 == 5)
            {
                Dice3Text.Text = " ⚄";
            }

            if (dice3 == 6)
            {
                Dice3Text.Text = " ⚅";
            }

            if (dice4 == 1)
            {
                Dice4Text.Text = " ⚀";
            }

            if (dice4 == 2)
            {
                Dice4Text.Text = " ⚁";
            }

            if (dice4 == 3)
            {
                Dice4Text.Text = " ⚂";
            }

            if (dice4 == 4)
            {
                Dice4Text.Text = " ⚃";
            }

            if (dice4 == 5)
            {
                Dice4Text.Text = " ⚄";
            }

            if (dice4 == 6)
            {
                Dice4Text.Text = " ⚅";
            }

            if (dice5 == 1)
            {
                Dice5Text.Text = " ⚀";
            }

            if (dice5 == 2)
            {
                Dice5Text.Text = " ⚁";
            }

            if (dice5 == 3)
            {
                Dice5Text.Text = " ⚂";
            }

            if (dice5 == 4)
            {
                Dice5Text.Text = " ⚃";
            }

            if (dice5 == 5)
            {
                Dice5Text.Text = " ⚄";
            }

            if (dice5 == 6)
            {
                Dice5Text.Text = " ⚅";
            }






        }
        public MainPage()
        {
            this.InitializeComponent();
        }




        private void CheckFor()
        {
            int[] i = new int[5];

            i[0] = dice1;
            i[1] = dice2;
            i[2] = dice3;
            i[3] = dice4;
            i[4] = dice5;

            Array.Sort(i);

            //Three of a kind

            if (((i[0] == 1) && (i[1] == 1) && (i[2] == 1)) ||
                ((i[0] == 2) && (i[1] == 2) && (i[2] == 2)) ||
                ((i[0] == 3) && (i[1] == 3) && (i[2] == 3)) ||
                ((i[0] == 4) && (i[1] == 4) && (i[2] == 4)) ||
                ((i[0] == 5) && (i[1] == 5) && (i[2] == 5)) ||
                ((i[0] == 6) && (i[1] == 6) && (i[2] == 6)) ||
                ((i[1] == 1) && (i[2] == 1) && (i[3] == 1)) ||
                ((i[1] == 2) && (i[2] == 2) && (i[3] == 2)) ||
                ((i[1] == 3) && (i[2] == 3) && (i[3] == 3)) ||
                ((i[1] == 4) && (i[2] == 4) && (i[3] == 4)) ||
                ((i[1] == 5) && (i[2] == 5) && (i[3] == 5)) ||
                ((i[1] == 6) && (i[2] == 6) && (i[3] == 6)) ||
                ((i[2] == 1) && (i[3] == 1) && (i[4] == 1)) ||
                ((i[2] == 2) && (i[3] == 2) && (i[4] == 2)) ||
                ((i[2] == 3) && (i[3] == 3) && (i[4] == 3)) ||
                ((i[2] == 4) && (i[3] == 4) && (i[4] == 4)) ||
                ((i[2] == 5) && (i[3] == 5) && (i[4] == 5)) ||
                ((i[2] == 6) && (i[3] == 6) && (i[4] == 6)))
            {
                ThreeOfAKindBool = true;
            }


            //Four of a kind

            if (((i[0] == 1) && (i[1] == 1) && (i[2] == 1) && (i[3] == 1)) ||
                ((i[0] == 2) && (i[1] == 2) && (i[2] == 2) && (i[3] == 2)) ||
                ((i[0] == 3) && (i[1] == 3) && (i[2] == 3) && (i[3] == 3)) ||
                ((i[0] == 4) && (i[1] == 4) && (i[2] == 4) && (i[3] == 4)) ||
                ((i[0] == 5) && (i[1] == 5) && (i[2] == 5) && (i[3] == 5)) ||
                ((i[0] == 6) && (i[1] == 6) && (i[2] == 6) && (i[3] == 6)) ||
                ((i[1] == 1) && (i[2] == 1) && (i[3] == 1) && (i[4] == 1)) ||
                ((i[1] == 2) && (i[2] == 2) && (i[3] == 2) && (i[4] == 2)) ||
                ((i[1] == 3) && (i[2] == 3) && (i[3] == 3) && (i[4] == 3)) ||
                ((i[1] == 4) && (i[2] == 4) && (i[3] == 4) && (i[4] == 4)) ||
                ((i[1] == 5) && (i[2] == 5) && (i[3] == 5) && (i[4] == 5)) ||
                ((i[1] == 6) && (i[2] == 6) && (i[3] == 6) && (i[4] == 6)))

            {
                FourOfAKindBool = true;
            }



            //Kleine Straat

            //Er komen problemen als er dezelfde nummers in voorkomen dus dit zorgt ervoor dat alle dubbele getallen naar links gaan
            //(source: https://www.codeproject.com/Articles/8657/A-Simple-Yahtzee-Game)
            for (int j = 0; j < 4; j++)
            {
                int temp = 0;
                if (i[j] == i[j + 1])
                {
                    temp = i[j];

                    for (int k = j; k < 4; k++)
                    {
                        i[k] = i[k + 1];
                    }

                    i[4] = temp;
                }
            }

            if (((i[0] == 1) && (i[1] == 2) && (i[2] == 3) && (i[3] == 4)) ||
                ((i[0] == 2) && (i[1] == 3) && (i[2] == 4) && (i[3] == 5)) ||
                ((i[0] == 3) && (i[1] == 4) && (i[2] == 5) && (i[3] == 6)) ||
                ((i[1] == 1) && (i[2] == 2) && (i[3] == 3) && (i[4] == 4)) ||
                ((i[1] == 2) && (i[2] == 3) && (i[3] == 4) && (i[4] == 5)) ||
                ((i[1] == 3) && (i[2] == 4) && (i[3] == 5) && (i[4] == 6)))
            {
                KleineStraatBool = true;
            }


            //Grote Straat

            if (((i[0] == 1) && (i[1] == 2) && (i[2] == 3) && (i[3] == 4) && (i[4] == 5)) ||
                ((i[0] == 2) && (i[1] == 3) && (i[2] == 4) && (i[3] == 5) && (i[4] == 6)))
            {
                GroteStraatBool = true;
            }

            //Yahtzee

            if (((i[0] == 1) && (i[1] == 1) && (i[2] == 1) && (i[3] == 1) && (i[4] == 1)) ||
                ((i[0] == 2) && (i[1] == 2) && (i[2] == 2) && (i[3] == 2) && (i[4] == 2)) ||
                ((i[0] == 3) && (i[1] == 3) && (i[2] == 3) && (i[3] == 3) && (i[4] == 3)) ||
                ((i[0] == 4) && (i[1] == 4) && (i[2] == 4) && (i[3] == 4) && (i[4] == 4)) ||
                ((i[0] == 5) && (i[1] == 5) && (i[2] == 5) && (i[3] == 5) && (i[4] == 5)) ||
                ((i[0] == 6) && (i[1] == 6) && (i[2] == 6) && (i[3] == 6) && (i[4] == 6)))

            {
                YahtzeeBool = true;
            }

            //FullHouse
            int[] fullHouseArr = new int[] { dice1, dice2, dice3, dice4, dice5 };
            Array.Sort(fullHouseArr);
            if ((((dice1 == dice2) && (dice2 == dice3)) &&
                     (dice4 == dice5) &&
                     (dice3 != dice4)) ||
                    ((dice1 == dice2) &&
                     ((dice3 == dice4) && (dice4 == dice5)) &&
                     (dice2 != dice3)))
            {
                FullHouseBool = true;
            }



        }



        private void ThrowButton_Click_1(object sender, RoutedEventArgs e)
        {
            if (WinnaarBool == false)
            {
                if (LockBoolDice1 == false)
                {
                   dice1 = random.Next(1, 7);
                }

                if (LockBoolDice2 == false)
                {
                    dice2 = random.Next(1, 7);
                }
                
                if (LockBoolDice3 == false)
                {
                    dice3 = random.Next(1, 7);
                }
                
                if (LockBoolDice4 == false)
                {
                    dice4 = random.Next(1, 7);
                }
                
                if (LockBoolDice5 == false)
                {
                    dice5 = random.Next(1, 7);
                }

                diceThrow = true;
                ChanceBool = true;



                NumberToDice();
                CheckFor();

                AantalPuntenR1Text.Text = AantalPuntenR1Number.ToString();

            }
            else
            {
                ThrowButton.Content = "Klaar";
            }



        }



        private void UitlegPageButton_Click(object sender, RoutedEventArgs e)
        {
            UitlegPage uitlegPage = new UitlegPage();
            this.Content = uitlegPage;
        }

        private void KiesThreeOfAKindButton_Click(object sender, RoutedEventArgs e)
        {
            if (ThreeOfAKindBool == true)
            {
                ThreeOfAKindR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                AantalPuntenR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                ThreeOfAKindR1Text.Text = ThreeOfAKindR1Number.ToString();
                ThreeOfAKindR3Number += 1;
                ThreeOfAKindR3Text.Text = ThreeOfAKindR3Number.ToString();
                RestFalse();
                LockLos();
            }


        }

        private void KiesFourOfAKindButton_Click(object sender, RoutedEventArgs e)
        {
            if (FourOfAKindBool == true)
            {
                FourOfAKindR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                AantalPuntenR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                FourOfAKindR1Text.Text = FourOfAKindR1Number.ToString();
                FourOfAKindR3Number += 1;
                fourOfAKindR3Text.Text = FourOfAKindR3Number.ToString();
                RestFalse();
                LockLos();
            }
        }

        private void KiesKleineStraatButton_Click(object sender, RoutedEventArgs e)
        {
            if (KleineStraatBool == true)
            {
                KleineStraatR1Number += 30;
                AantalPuntenR1Number += 30;
                KleineStraatR1Text.Text = KleineStraatR1Number.ToString();
                KleineStraatR3Number += 1;
                KleineStraatR3Text.Text = KleineStraatR3Number.ToString();
                RestFalse();
                LockLos();
            }


        }

        private void KiesFullHouseButton_Click(object sender, RoutedEventArgs e)
        {
            if (FullHouseBool == true)
            {
                FullHouseR1Number += 25;
                AantalPuntenR1Number += 25;
                FullHouseR1Text.Text = FullHouseR1Number.ToString();
                FullHouseR3Number += 1;
                FullHouseR3Text.Text = FullHouseR3Number.ToString();
                RestFalse();
                LockLos();
            }


        }

        private void KiesGroteStraatButton_Click(object sender, RoutedEventArgs e)
        {
            if (GroteStraatBool == true)
            {
                GroteStraatR1Number += 40;
                AantalPuntenR1Number += 40;
                GroteStraatR1Text.Text = GroteStraatR1Number.ToString();
                GroteStraatR3Number += 1;
                GroteStraatR3Text.Text = GroteStraatR3Number.ToString();
                RestFalse();
                LockLos();
            }


        }

        private void KiesChanceButton_Click(object sender, RoutedEventArgs e)
        {
            if (ChanceBool == true && ChanceR3Number == 0)
            {
                ChanceR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                AantalPuntenR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                ChanceR1Text.Text = ChanceR1Number.ToString();
                ChanceR3Number += 1;
                ChanceR3Text.Text = ChanceR3Number.ToString();
                RestFalse();
                LockLos();
            }


        }

        private void KiesYahtzeeButton_Click(object sender, RoutedEventArgs e)
        {
            if (YahtzeeBool == true)
            {
                YahtzeeR1Number += 50;
                AantalPuntenR1Number += 50;
                WinnaarBool = true;
                YahtzeeR1Text.Text = YahtzeeR1Number.ToString();
                YahtzeeR3Number += 1;
                YahtzeeR3Text.Text = YahtzeeR3Number.ToString();
                RestFalse();
                LockLos();

            }



        }

        private void LockDice1Button_Click(object sender, RoutedEventArgs e)
        {
            LockBoolDice1 = true;
        }

        private void LockDice2Button_Click(object sender, RoutedEventArgs e)
        {
            LockBoolDice2 = true;
        }

        private void LockDice3Button_Click(object sender, RoutedEventArgs e)
        {
            LockBoolDice3 = true;
        }

        private void LockDice4Button_Click(object sender, RoutedEventArgs e)
        {
            LockBoolDice4 = true;
        }

        private void LockDice5Button_Click(object sender, RoutedEventArgs e)
        {
            LockBoolDice5 = true;
        }
    }
}
