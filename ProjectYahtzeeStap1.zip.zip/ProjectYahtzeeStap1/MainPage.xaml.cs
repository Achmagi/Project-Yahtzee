﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace ProjectYahtzeeStap1
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        // Hier worden alle variabelen aangemaakt die worden gebruikt bij het spel om het spel goed te laten verlopen.
        Random random = new Random();

        public int dice1;
        public int dice2;
        public int dice3;
        public int dice4;
        public int dice5;

        public int groteStraatR1Number;
        public int kleineStraatR1Number;
        public int yahtzeeR1Number;
        public int fullHouseR1Number;
        public int fourOfAKindR1Number;
        public int threeOfAKindR1Number;
        public int chanceR1Number;
        public int aantalPuntenR1Number;

        public bool diceThrow = false;
        public bool groteStraatBool = false;
        public bool kleineStraatBool = false;
        public bool yahtzeeBool = false;
        public bool fullHouseBool = false;
        public bool fourOfAKindBool = false;
        public bool threeOfAKindBool = false;
        public bool chanceBool = false;

        // Dit zorgt ervoor dat de text in een dice vernaderd dus dat er geen cijfers maar dice worden gebruikt
        //Gemaakt door Ahmed 
        public void NumberToDice()
        {
            if (dice1 == 1)
            {
                Dice1Text.Text = " ⚀";
            }

            if (dice1 == 2)
            {
                Dice1Text.Text = " ⚁";
            }

            if (dice1 == 3)
            {
                Dice1Text.Text = " ⚂";
            }

            if (dice1 == 4)
            {
                Dice1Text.Text = " ⚃";
            }

            if (dice1 == 5)
            {
                Dice1Text.Text = " ⚄";
            }

            if (dice1 == 6)
            {
                Dice1Text.Text = " ⚅";
            }

            if (dice2 == 1)
            {
                Dice2Text.Text = " ⚀";
            }

            if (dice2 == 2)
            {
                Dice2Text.Text = " ⚁";
            }

            if (dice2 == 3)
            {
                Dice2Text.Text = " ⚂";
            }

            if (dice2 == 4)
            {
                Dice2Text.Text = " ⚃";
            }

            if (dice2 == 5)
            {
                Dice2Text.Text = " ⚄";
            }

            if (dice2 == 6)
            {
                Dice2Text.Text = " ⚅";
            }

            if (dice3 == 1)
            {
                Dice3Text.Text = " ⚀";
            }

            if (dice3 == 2)
            {
                Dice3Text.Text = " ⚁";
            }

            if (dice3 == 3)
            {
                Dice3Text.Text = " ⚂";
            }

            if (dice3 == 4)
            {
                Dice3Text.Text = " ⚃";
            }

            if (dice3 == 5)
            {
                Dice3Text.Text = " ⚄";
            }

            if (dice3 == 6)
            {
                Dice3Text.Text = " ⚅";
            }

            if (dice4 == 1)
            {
                Dice4Text.Text = " ⚀";
            }

            if (dice4 == 2)
            {
                Dice4Text.Text = " ⚁";
            }

            if (dice4 == 3)
            {
                Dice4Text.Text = " ⚂";
            }

            if (dice4 == 4)
            {
                Dice4Text.Text = " ⚃";
            }

            if (dice4 == 5)
            {
                Dice4Text.Text = " ⚄";
            }

            if (dice4 == 6)
            {
                Dice4Text.Text = " ⚅";
            }

            if (dice5 == 1)
            {
                Dice5Text.Text = " ⚀";
            }

            if (dice5 == 2)
            {
                Dice5Text.Text = " ⚁";
            }

            if (dice5 == 3)
            {
                Dice5Text.Text = " ⚂";
            }

            if (dice5 == 4)
            {
                Dice5Text.Text = " ⚃";
            }

            if (dice5 == 5)
            {
                Dice5Text.Text = " ⚄";
            }

            if (dice5 == 6)
            {
                Dice5Text.Text = " ⚅";
            }






        }
        public MainPage()
        {
            this.InitializeComponent();
        }

        //Dit checkt of je Yahtzee of Fullhouse etc. hebt gegooid
        //Gemaakt door Ahmed 
        private void CheckFor()
        {
            // Dit maakt een array van alle dice
            //Gemaakt door Ahmed 
            int[] i = new int[5];

            i[0] = dice1;
            i[1] = dice2;
            i[2] = dice3;
            i[3] = dice4;
            i[4] = dice5;

            Array.Sort(i);

            //Three of a kind

            //Dit checkt of er three of a kind is gegooid, zo ja dan zet die de ThreeOfAKindBool op true
            //Gemaakt door Ahmed 

            if (((i[0] == 1) && (i[1] == 1) && (i[2] == 1)) ||
                ((i[0] == 2) && (i[1] == 2) && (i[2] == 2)) ||
                ((i[0] == 3) && (i[1] == 3) && (i[2] == 3)) ||
                ((i[0] == 4) && (i[1] == 4) && (i[2] == 4)) ||
                ((i[0] == 5) && (i[1] == 5) && (i[2] == 5)) ||
                ((i[0] == 6) && (i[1] == 6) && (i[2] == 6)) ||
                ((i[1] == 1) && (i[2] == 1) && (i[3] == 1)) ||
                ((i[1] == 2) && (i[2] == 2) && (i[3] == 2)) ||
                ((i[1] == 3) && (i[2] == 3) && (i[3] == 3)) ||
                ((i[1] == 4) && (i[2] == 4) && (i[3] == 4)) ||
                ((i[1] == 5) && (i[2] == 5) && (i[3] == 5)) ||
                ((i[1] == 6) && (i[2] == 6) && (i[3] == 6)) ||
                ((i[2] == 1) && (i[3] == 1) && (i[4] == 1)) ||
                ((i[2] == 2) && (i[3] == 2) && (i[4] == 2)) ||
                ((i[2] == 3) && (i[3] == 3) && (i[4] == 3)) ||
                ((i[2] == 4) && (i[3] == 4) && (i[4] == 4)) ||
                ((i[2] == 5) && (i[3] == 5) && (i[4] == 5)) ||
                ((i[2] == 6) && (i[3] == 6) && (i[4] == 6)))
            {
                threeOfAKindBool = true;
            }


            //Four of a kind
            //Dit checkt of er four of a kind is gegooid, zo ja dan zet die de FourOfAKindBool op true
            //Gemaakt door Ahmed 

            if (((i[0] == 1) && (i[1] == 1) && (i[2] == 1) && (i[3] == 1)) ||
                ((i[0] == 2) && (i[1] == 2) && (i[2] == 2) && (i[3] == 2)) ||
                ((i[0] == 3) && (i[1] == 3) && (i[2] == 3) && (i[3] == 3)) ||
                ((i[0] == 4) && (i[1] == 4) && (i[2] == 4) && (i[3] == 4)) ||
                ((i[0] == 5) && (i[1] == 5) && (i[2] == 5) && (i[3] == 5)) ||
                ((i[0] == 6) && (i[1] == 6) && (i[2] == 6) && (i[3] == 6)) ||
                ((i[1] == 1) && (i[2] == 1) && (i[3] == 1) && (i[4] == 1)) ||
                ((i[1] == 2) && (i[2] == 2) && (i[3] == 2) && (i[4] == 2)) ||
                ((i[1] == 3) && (i[2] == 3) && (i[3] == 3) && (i[4] == 3)) ||
                ((i[1] == 4) && (i[2] == 4) && (i[3] == 4) && (i[4] == 4)) ||
                ((i[1] == 5) && (i[2] == 5) && (i[3] == 5) && (i[4] == 5)) ||
                ((i[1] == 6) && (i[2] == 6) && (i[3] == 6) && (i[4] == 6)))
            {
                fourOfAKindBool = true;
            }

            //Kleine Straat
            //Dit checkt of er kleine straat is gegooid, zo ja dan zet die de KleineStraatBool op true
            //Gemaakt door Ahmed 

            //Er komen problemen als er dezelfde nummers in voorkomen dus dit zorgt ervoor dat alle dubbele getallen naar links gaan
            //(source: https://www.codeproject.com/Articles/8657/A-Simple-Yahtzee-Game)
            for (int j = 0; j < 4; j++)
            {
                int temp = 0;
                if (i[j] == i[j + 1])
                {
                    temp = i[j];

                    for (int k = j; k < 4; k++)
                    {
                        i[k] = i[k + 1];
                    }

                    i[4] = temp;
                }
            }

            if (((i[0] == 1) && (i[1] == 2) && (i[2] == 3) && (i[3] == 4)) ||
                ((i[0] == 2) && (i[1] == 3) && (i[2] == 4) && (i[3] == 5)) ||
                ((i[0] == 3) && (i[1] == 4) && (i[2] == 5) && (i[3] == 6)) ||
                ((i[1] == 1) && (i[2] == 2) && (i[3] == 3) && (i[4] == 4)) ||
                ((i[1] == 2) && (i[2] == 3) && (i[3] == 4) && (i[4] == 5)) ||
                ((i[1] == 3) && (i[2] == 4) && (i[3] == 5) && (i[4] == 6)))
            {
                kleineStraatBool = true;
            }

            //Grote Straat
            //Dit checkt of er grote straat is gegooid, zo ja dan zet die de GroteStraatBool op true
            //Gemaakt door Ahmed 

            if (((i[0] == 1) && (i[1] == 2) && (i[2] == 3) && (i[3] == 4) && (i[4] == 5)) ||
                ((i[0] == 2) && (i[1] == 3) && (i[2] == 4) && (i[3] == 5) && (i[4] == 6)))
            {
                groteStraatBool = true;
            }

            //Yahtzee
            //Dit checkt of er Yahtzee is gegooid, zo ja dan zet die de YahtzeeBool op true
            //Gemaakt door Ahmed 

            if (((i[0] == 1) && (i[1] == 1) && (i[2] == 1) && (i[3] == 1) && (i[4] == 1)) ||
                ((i[0] == 2) && (i[1] == 2) && (i[2] == 2) && (i[3] == 2) && (i[4] == 2)) ||
                ((i[0] == 3) && (i[1] == 3) && (i[2] == 3) && (i[3] == 3) && (i[4] == 3)) ||
                ((i[0] == 4) && (i[1] == 4) && (i[2] == 4) && (i[3] == 4) && (i[4] == 4)) ||
                ((i[0] == 5) && (i[1] == 5) && (i[2] == 5) && (i[3] == 5) && (i[4] == 5)) ||
                ((i[0] == 6) && (i[1] == 6) && (i[2] == 6) && (i[3] == 6) && (i[4] == 6)))

            {
                yahtzeeBool = true;
            }

            //FullHouse
            int[] arr = new int[] { dice1, dice2, dice3, dice4, dice5 };
            Array.Sort(arr);
            if ((((dice1 == dice2) && (dice2 == dice3)) &&
                     (dice4 == dice5) &&
                     (dice3 != dice4)) ||
                    ((dice1 == dice2) &&
                     ((dice3 == dice4) && (dice4 == dice5)) &&
                     (dice2 != dice3)))
            {
                fullHouseBool = true;
            }



        }

        private void ThrowButton_Click_1(object sender, RoutedEventArgs e)
        {
            dice1 = random.Next(1, 7);
            dice2 = random.Next(1, 7);
            dice3 = random.Next(1, 7);
            dice4 = random.Next(1, 7);
            dice5 = random.Next(1, 7);

            diceThrow = true;
            chanceBool = true;


            NumberToDice();
            CheckFor();

            AantalPuntenR1Text.Text = aantalPuntenR1Number.ToString();



        }



        private void UitlegPageButton_Click(object sender, RoutedEventArgs e)
        {
            UitlegPage uitlegPage = new UitlegPage();
            this.Content = uitlegPage;
        }

        private void KiesThreeOfAKindButton_Click(object sender, RoutedEventArgs e)
        {
            if (threeOfAKindBool == true)
            {
                threeOfAKindR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                aantalPuntenR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                ThreeOfAKindR1Text.Text = threeOfAKindR1Number.ToString();
                threeOfAKindBool = false;
            }


        }

        private void KiesFourOfAKindButton_Click(object sender, RoutedEventArgs e)
        {
            if (fourOfAKindBool == true)
            {
                fourOfAKindR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                aantalPuntenR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                FourOfAKindR1Text.Text = fourOfAKindR1Number.ToString();
                fourOfAKindBool = false;
            }
        }

        private void KiesKleineStraatButton_Click(object sender, RoutedEventArgs e)
        {
            if (kleineStraatBool == true)
            {
                kleineStraatR1Number += 30;
                aantalPuntenR1Number += 30;
                KleineStraatR1Text.Text = kleineStraatR1Number.ToString();
                kleineStraatBool = false;
            }


        }

        private void KiesFullHouseButton_Click(object sender, RoutedEventArgs e)
        {
            if (fullHouseBool == true)
            {
                fullHouseR1Number += 25;
                aantalPuntenR1Number += 25;
                FullHouseR1Text.Text = fullHouseR1Number.ToString();
                fullHouseBool = false;
            }


        }

        private void KiesGroteStraatButton_Click(object sender, RoutedEventArgs e)
        {
            if (groteStraatBool == true)
            {
                groteStraatBool = true;
                groteStraatR1Number += 40;
                aantalPuntenR1Number += 40;
                GroteStraatR1Text.Text = groteStraatR1Number.ToString();
            }


        }

        private void KiesChanceButton_Click(object sender, RoutedEventArgs e)
        {
            if (chanceBool == true)
            {
                chanceR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                aantalPuntenR1Number += dice1 + dice2 + dice3 + dice4 + dice5;
                ChanceR1Text.Text = chanceR1Number.ToString();
                chanceBool = false;
            }


        }

        private void KiesYahtzeeButton_Click(object sender, RoutedEventArgs e)
        {
            if (yahtzeeBool == true)
            {
                yahtzeeR1Number += 50;
                aantalPuntenR1Number += 50;

                YahtzeeR1Text.Text = yahtzeeR1Number.ToString();
                yahtzeeBool = false;
            }


        }

    }
}
